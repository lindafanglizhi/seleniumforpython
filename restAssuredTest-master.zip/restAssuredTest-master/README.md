# restAssuredTest
interface test for restAssured
this is my first testcode for restAssured
